package com.example.hellotoast;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.hellotoast.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    private int count = 0;

    public static ActivityMainBinding mainBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        mainBinding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(mainBinding.getRoot());

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        if (savedInstanceState != null) {
            count = savedInstanceState.getInt("count_key", 0);
            mainBinding.textDisplayCount.setText(String.valueOf(count));

            if (count > 0) {
                if (count % 2 == 0) {
                    mainBinding.buttonCount.setBackgroundTintList(ContextCompat.getColorStateList(this, android.R.color.holo_blue_dark));
                } else {
                    mainBinding.buttonCount.setBackgroundTintList(ContextCompat.getColorStateList(this, android.R.color.holo_green_dark));
                }
                mainBinding.buttonZero.setBackgroundTintList(ContextCompat.getColorStateList(this, android.R.color.holo_orange_dark));
            } else {
                mainBinding.buttonZero.setBackgroundTintList(ContextCompat.getColorStateList(this, android.R.color.darker_gray));
            }
        } else {
            mainBinding.buttonZero.setBackgroundTintList(ContextCompat.getColorStateList(this, android.R.color.darker_gray));
        }
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("count_key", count);
    }

    public void show_toast(View view) {
        Toast.makeText(this, "Hello Toast", Toast.LENGTH_SHORT).show();
    }

    public void increase_count(View view) {
        count++;
        mainBinding.textDisplayCount.setText(String.valueOf(count));

        if (count % 2 == 0) {
            mainBinding.buttonCount.setBackgroundTintList(ContextCompat.getColorStateList(this, android.R.color.holo_blue_dark));
        } else {
            mainBinding.buttonCount.setBackgroundTintList(ContextCompat.getColorStateList(this, android.R.color.holo_green_dark));
        }

        mainBinding.buttonZero.setBackgroundTintList(ContextCompat.getColorStateList(this, android.R.color.holo_orange_dark));
    }

    public void showZero(View view) {
        count = 0;
        mainBinding.textDisplayCount.setText(String.valueOf(count));

        mainBinding.buttonZero.setBackgroundTintList(ContextCompat.getColorStateList(this, android.R.color.darker_gray));
    }
}